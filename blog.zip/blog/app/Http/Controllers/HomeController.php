<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Models\User;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('newCode');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
                'name' => 'required',
                'age' => 'required',
                'password' => 'required|min:5',
                'mobile' => 'required|min:11',
                'address' => 'required'
            ], [
                'name.required' => 'Name is required',
                'age.required' => 'age is required',
                'password.required' => 'Password is required',
                'mobile.required' => 'mobile number is required',
                'address.required' => 'address is required',

              
            
            ]);
  
        $validatedData['password'] = bcrypt($validatedData['password']);
        $user = User::create($validatedData);
      
        return back()->with('success', 'User created successfully.');
    }
}