<?php




namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;

use Illuminate\Http\Request;
//use App\Models\Register;
//use App\Models\User;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('newCode');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
      

        public function store(Request $request)
        {
            $this->validate($request,
                [
                    'name'=>"required|string",
                    'gender'=>'required',
                    'password'=>'required|string',
                    'mobile' => 'required|min:11',
                    'address' => 'required',
       
    
                ]
               
            );
            $output ="<h1>Submitted</h1>";
            $output.="Name : ".$request->name;
            $output.="<br>Gender : ".$request->gender;
            $output.="<br>Password : ".$request->password;
            $output.="<br>Mobile number : ".$request->mobile;
            $output.="<br>Address : ".$request->address;
            return $output;
        }
        
    }


