<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;


class Job_Seeker extends Model
{
    protected $table = 'job_seeker';
    public $timestamps = false;
}
