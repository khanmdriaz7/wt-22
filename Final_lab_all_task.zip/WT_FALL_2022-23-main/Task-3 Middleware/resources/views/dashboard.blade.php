@extends('layout.dashboardlayout')

@section('title')
Dashboard
@endsection

@section('content')
<div class="row">
    <div class="col-lg">
        <h1>Welcome {{$un}}</h1>
    </div>
</div>
@endsection